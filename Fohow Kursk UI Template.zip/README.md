
  # Fohow Kursk UI Template

  This is a code bundle for Fohow Kursk UI Template. The original project is available at https://www.figma.com/design/iQdQ0lI0yEGg6Q60GW99Rk/Fohow-Kursk-UI-Template.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  